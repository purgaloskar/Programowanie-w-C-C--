#ifndef FILE_VALIDATOR_HPP
#define FILE_VALIDATOR_HPP

#include <string>

bool sprawdzPoprawnoscPliku(const std::string& nazwa_pliku, std::string& blad);

#endif

