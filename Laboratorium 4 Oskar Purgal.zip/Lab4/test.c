#include <stdio.h>

int main() {
    for (int i = 0; i < 5; i++) {
        printf("Iteracja %d\n", i);
    }
    return 0;
}
